// [LocationMagic] [inject.js] - Main World Injector
// Runs in the PAGE's JS context. Reads initial state from DOM attribute
// stamped by content.js, then listens for live updates via CustomEvent.

(function () {
    'use strict';

    const STATE_ATTR = 'data-lm-spoof';

    // ──────────────────────────────────────────────
    // 1. Read initial state SYNCHRONOUSLY from DOM attribute
    // ──────────────────────────────────────────────
    let state = {
        spoofEnabled: false,
        latitude: 48.8566,
        longitude: 2.3522,
        accuracy: 10
    };

    try {
        const raw = document.documentElement.getAttribute(STATE_ATTR);
        if (raw) {
            state = Object.assign({}, state, JSON.parse(raw));
        }
    } catch (e) { /* will receive real state via event */ }

    // ──────────────────────────────────────────────
    // 2. Listen for live state sync from content.js
    // ──────────────────────────────────────────────
    window.addEventListener('__locationMagicSync', function (e) {
        if (e && e.detail) {
            state = Object.assign({}, state, e.detail);
        }
    });

    // ──────────────────────────────────────────────
    // 3. Build a fake position — plain object only.
    //    NO prototype hacking: Google Maps validates internal
    //    slots and will throw TypeError on fake prototypes.
    //    A plain object with the right properties is enough.
    // ──────────────────────────────────────────────
    function buildFakePosition() {
        return {
            coords: {
                latitude: Number(state.latitude),
                longitude: Number(state.longitude),
                accuracy: Number(state.accuracy) || 10,
                altitude: null,
                altitudeAccuracy: null,
                heading: null,
                speed: null
            },
            timestamp: Date.now()
        };
    }

    // ──────────────────────────────────────────────
    // 4. Capture native BEFORE overriding
    // ──────────────────────────────────────────────
    var _native = navigator.geolocation;
    if (!_native) return; // page doesn't support geolocation

    // ──────────────────────────────────────────────
    // 5. Spoofed geolocation object
    // ──────────────────────────────────────────────
    var _spoofed = {
        getCurrentPosition: function (successCb, errorCb, opts) {
            if (!state.spoofEnabled) {
                return _native.getCurrentPosition.call(_native, successCb, errorCb, opts);
            }
            setTimeout(function () {
                try {
                    successCb(buildFakePosition());
                } catch (e) {
                    if (typeof errorCb === 'function') {
                        errorCb({ code: 2, message: 'LocationMagic internal error: ' + e.message });
                    }
                }
            }, 50);
        },

        watchPosition: function (successCb, errorCb, opts) {
            if (!state.spoofEnabled) {
                return _native.watchPosition.call(_native, successCb, errorCb, opts);
            }
            function fire() {
                try { successCb(buildFakePosition()); }
                catch (e) { if (typeof errorCb === 'function') errorCb({ code: 2 }); }
            }
            fire();
            return setInterval(fire, 2000);
        },

        clearWatch: function (id) {
            if (!state.spoofEnabled) {
                return _native.clearWatch.call(_native, id);
            }
            clearInterval(id);
        }
    };

    // ──────────────────────────────────────────────
    // 6. Override navigator.geolocation via defineProperty
    // ──────────────────────────────────────────────
    try {
        Object.defineProperty(navigator, 'geolocation', {
            get: function () {
                return state.spoofEnabled ? _spoofed : _native;
            },
            configurable: true,
            enumerable: true
        });
        console.log(
            '%c[LocationMagic] GPS Spoofer injected. spoofEnabled=' + state.spoofEnabled,
            'color:#8b5cf6;font-weight:bold;'
        );
    } catch (err) {
        console.error('[LocationMagic] Could not override navigator.geolocation:', err.message);
    }

})();
