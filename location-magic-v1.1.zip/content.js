// [LocationMagic] [content.js] - Content Script (ISOLATED world)
// STRATEGY:
//   1. Immediately set defaults on DOM attribute (synchronous, zero latency)
//   2. Immediately inject inject.js — it reads DOM attr synchronously
//   3. Then read real storage values and sync them via CustomEvent

'use strict';

const STATE_ATTR = 'data-lm-spoof';

// Step 1 — Set defaults immediately so inject.js always has something to read.
// inject.js runs synchronously after the <script> tag is appended.
document.documentElement.setAttribute(STATE_ATTR, JSON.stringify({
    spoofEnabled: false,
    latitude: 48.8566,
    longitude: 2.3522,
    accuracy: 10
}));

// Step 2 — Inject into the page's MAIN WORLD right now (with defaults above).
let injected = false;

function injectScript() {
    if (injected) return;
    injected = true;

    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('inject.js');

    // After inject.js loads, dispatch the real state from storage
    script.onload = () => {
        script.remove();
        syncStateFromStorage();
    };

    (document.head || document.documentElement).appendChild(script);
}

// Step 3 — Read real stored values and notify inject.js via CustomEvent.
function syncStateFromStorage() {
    chrome.storage.local.get(
        ['spoofEnabled', 'latitude', 'longitude', 'accuracy'],
        (data) => {
            // Update DOM attribute too (for any future reloads)
            document.documentElement.setAttribute(STATE_ATTR, JSON.stringify({
                spoofEnabled: data.spoofEnabled || false,
                latitude: data.latitude || 48.8566,
                longitude: data.longitude || 2.3522,
                accuracy: data.accuracy || 10
            }));

            // Dispatch event to the running inject.js
            window.dispatchEvent(
                new CustomEvent('__locationMagicSync', {
                    detail: {
                        spoofEnabled: data.spoofEnabled || false,
                        latitude: data.latitude || 48.8566,
                        longitude: data.longitude || 2.3522,
                        accuracy: data.accuracy || 10
                    }
                })
            );
        }
    );
}

// Boot — inject now
injectScript();

// ────────────────────────────────────────────────
// Listen for live state changes from popup → background → here
// ────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message) => {
    if (message.type !== 'STATE_CHANGED') return;

    const state = {
        spoofEnabled: message.spoofEnabled || false,
        latitude: message.latitude || 48.8566,
        longitude: message.longitude || 2.3522,
        accuracy: message.accuracy || 10
    };

    // Update DOM attribute
    document.documentElement.setAttribute(STATE_ATTR, JSON.stringify(state));

    // Notify inject.js in the page's main world
    window.dispatchEvent(
        new CustomEvent('__locationMagicSync', { detail: state })
    );
});
